package com.cognizant.service;

import com.cognizant.dao.IPODetailsDAO;

public class IPOServiceImpl implements IPODetailsDAO {

	@Override
	public boolean updateIPOData(int id) {
		// TODO Auto-generated method stub
		return false;
	}

}
