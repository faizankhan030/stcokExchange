package com.cognizant.service;

import com.cognizant.entity.User;

public interface UserService {
	
	User getInternById(int userId);
	boolean storeInternData(User user);
	boolean updateUserData(User user);
}
