package com.cognizant.service;

public interface CompanyService {

}
