package com.cognizant.service;

public interface IPOService {
	boolean updateIPOData(int id);
}
