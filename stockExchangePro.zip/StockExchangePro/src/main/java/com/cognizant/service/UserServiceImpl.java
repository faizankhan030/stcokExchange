package com.cognizant.service;

import com.cognizant.entity.User;

public class UserServiceImpl implements UserService {

	@Override
	public User getInternById(int userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean storeInternData(User user) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean updateUserData(User user) {
		// TODO Auto-generated method stub
		return false;
	}

}
