package com.cognizant.service;

public class CompanyServiceImpl implements CompanyService {

}
