package com.cognizant.dao;

public interface IPODetailsDAO {
	
	boolean updateIPOData(int id);
}
