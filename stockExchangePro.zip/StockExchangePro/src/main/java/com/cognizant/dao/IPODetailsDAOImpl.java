package com.cognizant.dao;

public class IPODetailsDAOImpl implements IPODetailsDAO {

	@Override
	public boolean updateIPOData(int id) {
		// TODO Auto-generated method stub
		return false;
	}

}
