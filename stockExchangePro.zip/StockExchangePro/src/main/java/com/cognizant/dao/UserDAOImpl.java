package com.cognizant.dao;

public class UserDAOImpl {

}
