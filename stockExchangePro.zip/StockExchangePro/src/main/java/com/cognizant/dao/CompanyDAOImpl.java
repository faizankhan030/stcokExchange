package com.cognizant.dao;

public class CompanyDAOImpl implements CompanyDAO {

}
