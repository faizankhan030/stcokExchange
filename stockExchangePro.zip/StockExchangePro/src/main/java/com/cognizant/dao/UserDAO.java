package com.cognizant.dao;


import com.cognizant.entity.User;

public interface UserDAO {
	
	User getInternById(int userId);
	boolean storeInternData(User user);
	boolean updateUserData(User user);
}
