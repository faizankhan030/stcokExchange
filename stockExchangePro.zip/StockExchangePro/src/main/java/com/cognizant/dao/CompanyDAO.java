package com.cognizant.dao;

public interface CompanyDAO {
	
}
