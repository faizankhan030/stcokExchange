package com.cognizant.entity;

import java.sql.Date;
import java.sql.Time;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="StockPrice")
public class StockPrice {
	

	@Id
	@Column(name="companyCode")
	private int copmanyCode;
	
	@Column(name="stockExchange")
	private String stockExchange;
	
	@Column(name="currentPrice")
	private float currentPrice;
	
	@Column(name="currentDate")
	private Date date;
	
	@Column(name="currentTime")
	private Time time;
	
	public int getCopmanyCode() {
		return copmanyCode;
	}

	public void setCopmanyCode(int copmanyCode) {
		this.copmanyCode = copmanyCode;
	}

	public String getStockExchange() {
		return stockExchange;
	}

	public void setStockExchange(String stockExchange) {
		this.stockExchange = stockExchange;
	}

	public float getCurrentPrice() {
		return currentPrice;
	}

	public void setCurrentPrice(float currentPrice) {
		this.currentPrice = currentPrice;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public Time getTime() {
		return time;
	}

	public void setTime(Time time) {
		this.time = time;
	}

	
}
